package com.wms.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ValidatorTest {

    @Test
    void phoneValidationWorks() {
        assertTrue(Validator.isValidPhone("9876543210"));
        assertFalse(Validator.isValidPhone("12345"));
    }

    @Test
    void emailValidationWorks() {
        assertTrue(Validator.isValidEmail("user@example.com"));
        assertFalse(Validator.isValidEmail("bad-email"));
    }

    @Test
    void locationValidationWorks() {
        assertTrue(Validator.isValidLocation("A1"));
        assertTrue(Validator.isValidLocation("B20"));
        assertFalse(Validator.isValidLocation("aisle-1"));
    }
}
