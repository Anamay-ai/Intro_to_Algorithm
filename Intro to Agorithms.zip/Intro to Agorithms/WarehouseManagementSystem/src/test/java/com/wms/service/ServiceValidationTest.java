package com.wms.service;

import com.wms.dao.InventoryDAO;
import com.wms.dao.ProductDAO;
import com.wms.dao.SupplierDAO;
import com.wms.dao.TransactionDAO;
import com.wms.model.Product;
import com.wms.model.Supplier;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;

class ServiceValidationTest {

    @Test
    void addProductShouldFailForBlankName() {
        Service service = new Service(new FakeProductDAO(), new FakeSupplierDAO(), new FakeInventoryDAO(), new FakeTransactionDAO());
        assertThrows(IllegalArgumentException.class,
                () -> service.addProduct(new Product(0, "", "Electronics", 10.0, 1)));
    }

    @Test
    void addSupplierShouldFailForInvalidPhone() {
        Service service = new Service(new FakeProductDAO(), new FakeSupplierDAO(), new FakeInventoryDAO(), new FakeTransactionDAO());
        assertThrows(IllegalArgumentException.class,
                () -> service.addSupplier(new Supplier(0, "ABC", "12", "a@b.com", "Addr")));
    }

    private static class FakeProductDAO implements ProductDAO {
        @Override
        public void add(Product product) {
        }

        @Override
        public List<Product> getAll() {
            return new ArrayList<>();
        }

        @Override
        public Optional<Product> getById(int productId) {
            return Optional.empty();
        }

        @Override
        public void update(Product product) {
        }

        @Override
        public void delete(int productId) {
        }

        @Override
        public List<Product> searchByName(String keyword) {
            return new ArrayList<>();
        }
    }

    private static class FakeSupplierDAO implements SupplierDAO {
        @Override
        public void add(Supplier supplier) {
        }

        @Override
        public List<Supplier> getAll() {
            return new ArrayList<>();
        }

        @Override
        public Optional<Supplier> getById(int supplierId) {
            return Optional.empty();
        }

        @Override
        public void update(Supplier supplier) {
        }

        @Override
        public void delete(int supplierId) {
        }

        @Override
        public List<Supplier> searchByName(String keyword) {
            return new ArrayList<>();
        }
    }

    private static class FakeInventoryDAO implements InventoryDAO {
        @Override
        public void add(com.wms.model.Inventory record) {
        }

        @Override
        public List<com.wms.model.Inventory> getAll() {
            return new ArrayList<>();
        }

        @Override
        public Optional<com.wms.model.Inventory> getByProductId(int productId) {
            return Optional.empty();
        }

        @Override
        public void updateQuantity(int productId, int quantity) {
        }

        @Override
        public void deleteByProductId(int productId) {
        }
    }

    private static class FakeTransactionDAO implements TransactionDAO {
        @Override
        public void add(com.wms.model.Transaction transaction) {
        }

        @Override
        public List<com.wms.model.Transaction> getAll() {
            return new ArrayList<>();
        }

        @Override
        public List<com.wms.model.Transaction> getByProductId(int productId) {
            return new ArrayList<>();
        }
    }
}
