package com.wms.model;

import java.time.LocalDateTime;

public class Transaction {
    private int transactionId;
    private int productId;
    private Integer supplierId;
    private TransactionType transactionType;
    private int quantity;
    private LocalDateTime transactionDate;

    public Transaction() {
    }

    public Transaction(int transactionId, int productId, Integer supplierId,
                            TransactionType transactionType, int quantity, LocalDateTime transactionDate) {
        this.transactionId = transactionId;
        this.productId = productId;
        this.supplierId = supplierId;
        this.transactionType = transactionType;
        this.quantity = quantity;
        this.transactionDate = transactionDate;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public Integer getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Integer supplierId) {
        this.supplierId = supplierId;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDateTime transactionDate) {
        this.transactionDate = transactionDate;
    }

    @Override
    public String toString() {
        return "Transaction ID: " + transactionId + ", Product ID: " + productId
                + ", Supplier ID: " + supplierId + ", Type: " + transactionType
                + ", Quantity: " + quantity + ", Date: " + transactionDate;
    }
}
