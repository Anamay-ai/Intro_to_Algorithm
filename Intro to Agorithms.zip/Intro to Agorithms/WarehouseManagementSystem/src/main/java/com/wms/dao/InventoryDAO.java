package com.wms.dao;

import com.wms.model.Inventory;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface InventoryDAO {
    void add(Inventory record) throws SQLException;

    List<Inventory> getAll() throws SQLException;

    Optional<Inventory> getByProductId(int productId) throws SQLException;

    void updateQuantity(int productId, int quantity) throws SQLException;

    void deleteByProductId(int productId) throws SQLException;
}
