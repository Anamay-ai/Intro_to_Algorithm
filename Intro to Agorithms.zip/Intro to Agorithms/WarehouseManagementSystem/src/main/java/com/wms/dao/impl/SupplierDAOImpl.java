package com.wms.dao.impl;

import com.wms.dao.SupplierDAO;
import com.wms.model.Supplier;
import com.wms.util.DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SupplierDAOImpl implements SupplierDAO {

    @Override
    public void add(Supplier supplier) throws SQLException {
        String sql = "INSERT INTO suppliers(name, phone, email, address) VALUES (?, ?, ?, ?)";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, supplier.getName());
            statement.setString(2, supplier.getPhone());
            statement.setString(3, supplier.getEmail());
            statement.setString(4, supplier.getAddress());
            statement.executeUpdate();
        }
    }

    @Override
    public List<Supplier> getAll() throws SQLException {
        List<Supplier> suppliers = new ArrayList<>();
        String sql = "SELECT supplier_id, name, phone, email, address FROM suppliers ORDER BY supplier_id";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                suppliers.add(map(resultSet));
            }
        }
        return suppliers;
    }

    @Override
    public Optional<Supplier> getById(int supplierId) throws SQLException {
        String sql = "SELECT supplier_id, name, phone, email, address FROM suppliers WHERE supplier_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, supplierId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(map(resultSet));
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public void update(Supplier supplier) throws SQLException {
        String sql = "UPDATE suppliers SET name = ?, phone = ?, email = ?, address = ? WHERE supplier_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, supplier.getName());
            statement.setString(2, supplier.getPhone());
            statement.setString(3, supplier.getEmail());
            statement.setString(4, supplier.getAddress());
            statement.setInt(5, supplier.getId());
            statement.executeUpdate();
        }
    }

    @Override
    public void delete(int supplierId) throws SQLException {
        String sql = "DELETE FROM suppliers WHERE supplier_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, supplierId);
            statement.executeUpdate();
        }
    }

    @Override
    public List<Supplier> searchByName(String keyword) throws SQLException {
        List<Supplier> suppliers = new ArrayList<>();
        String sql = "SELECT supplier_id, name, phone, email, address FROM suppliers WHERE LOWER(name) LIKE LOWER(?)";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "%" + keyword + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    suppliers.add(map(resultSet));
                }
            }
        }
        return suppliers;
    }

    private Supplier map(ResultSet resultSet) throws SQLException {
        return new Supplier(
                resultSet.getInt("supplier_id"),
                resultSet.getString("name"),
                resultSet.getString("phone"),
                resultSet.getString("email"),
                resultSet.getString("address")
        );
    }
}
