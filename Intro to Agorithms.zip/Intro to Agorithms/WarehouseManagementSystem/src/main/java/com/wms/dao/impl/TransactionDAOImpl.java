package com.wms.dao.impl;

import com.wms.dao.TransactionDAO;
import com.wms.model.Transaction;
import com.wms.model.TransactionType;
import com.wms.util.DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAOImpl implements TransactionDAO {

    @Override
    public void add(Transaction transaction) throws SQLException {
        String sql = "INSERT INTO stock_transactions(product_id, supplier_id, transaction_type, quantity, transaction_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, transaction.getProductId());
            if (transaction.getSupplierId() == null) {
                statement.setNull(2, java.sql.Types.INTEGER);
            } else {
                statement.setInt(2, transaction.getSupplierId());
            }
            statement.setString(3, transaction.getTransactionType().name());
            statement.setInt(4, transaction.getQuantity());
            statement.setTimestamp(5, Timestamp.valueOf(transaction.getTransactionDate()));
            statement.executeUpdate();
        }
    }

    @Override
    public List<Transaction> getAll() throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT transaction_id, product_id, supplier_id, transaction_type, quantity, transaction_date FROM stock_transactions ORDER BY transaction_id";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                transactions.add(map(resultSet));
            }
        }
        return transactions;
    }

    @Override
    public List<Transaction> getByProductId(int productId) throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT transaction_id, product_id, supplier_id, transaction_type, quantity, transaction_date FROM stock_transactions WHERE product_id = ? ORDER BY transaction_id";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, productId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    transactions.add(map(resultSet));
                }
            }
        }
        return transactions;
    }

    private Transaction map(ResultSet resultSet) throws SQLException {
        Timestamp timestamp = resultSet.getTimestamp("transaction_date");
        LocalDateTime dateTime = timestamp == null ? null : timestamp.toLocalDateTime();
        return new Transaction(
                resultSet.getInt("transaction_id"),
                resultSet.getInt("product_id"),
                resultSet.getObject("supplier_id", Integer.class),
                TransactionType.valueOf(resultSet.getString("transaction_type")),
                resultSet.getInt("quantity"),
                dateTime
        );
    }
}
