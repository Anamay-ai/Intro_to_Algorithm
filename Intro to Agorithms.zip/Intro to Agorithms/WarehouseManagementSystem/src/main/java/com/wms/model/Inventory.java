package com.wms.model;

public class Inventory {
    private int inventoryId;
    private int productId;
    private int quantityAvailable;
    private String warehouseLocation;

    public Inventory() {
    }

    public Inventory(int inventoryId, int productId, int quantityAvailable, String warehouseLocation) {
        this.inventoryId = inventoryId;
        this.productId = productId;
        this.quantityAvailable = quantityAvailable;
        this.warehouseLocation = warehouseLocation;
    }

    public int getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(int inventoryId) {
        this.inventoryId = inventoryId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantityAvailable() {
        return quantityAvailable;
    }

    public void setQuantityAvailable(int quantityAvailable) {
        this.quantityAvailable = quantityAvailable;
    }

    public String getWarehouseLocation() {
        return warehouseLocation;
    }

    public void setWarehouseLocation(String warehouseLocation) {
        this.warehouseLocation = warehouseLocation;
    }

    @Override
    public String toString() {
        return "Inventory ID: " + inventoryId + ", Product ID: " + productId
                + ", Quantity: " + quantityAvailable + ", Location: " + warehouseLocation;
    }
}
