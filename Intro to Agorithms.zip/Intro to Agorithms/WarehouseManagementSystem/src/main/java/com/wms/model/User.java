package com.wms.model;

public class User {
    // Encapsulation: the user state is kept private and exposed through getters/setters.
    private int id;
    private String username;
    private String password;
    private Role role;

    public User() {
    }

    // Constructor usage: creates a fully initialised user object.
    public User(int id, String username, String password, Role role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
