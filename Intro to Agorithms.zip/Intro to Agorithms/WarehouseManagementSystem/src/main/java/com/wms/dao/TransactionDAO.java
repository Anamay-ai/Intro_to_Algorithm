package com.wms.dao;

import com.wms.model.Transaction;

import java.sql.SQLException;
import java.util.List;

public interface TransactionDAO {
    void add(Transaction transaction) throws SQLException;

    List<Transaction> getAll() throws SQLException;

    List<Transaction> getByProductId(int productId) throws SQLException;
}
