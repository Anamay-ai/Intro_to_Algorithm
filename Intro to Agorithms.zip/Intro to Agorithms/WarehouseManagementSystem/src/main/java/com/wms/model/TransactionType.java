package com.wms.model;

public enum TransactionType {
    IN,
    OUT
}
