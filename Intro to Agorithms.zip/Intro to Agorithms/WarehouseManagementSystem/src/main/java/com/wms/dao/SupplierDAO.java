package com.wms.dao;

import com.wms.model.Supplier;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface SupplierDAO {
    void add(Supplier supplier) throws SQLException;

    List<Supplier> getAll() throws SQLException;

    Optional<Supplier> getById(int supplierId) throws SQLException;

    void update(Supplier supplier) throws SQLException;

    void delete(int supplierId) throws SQLException;

    List<Supplier> searchByName(String keyword) throws SQLException;
}
