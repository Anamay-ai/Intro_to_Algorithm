package com.wms.service;

import com.wms.dao.InventoryDAO;
import com.wms.dao.ProductDAO;
import com.wms.dao.TransactionDAO;
import com.wms.dao.SupplierDAO;
import com.wms.model.Inventory;
import com.wms.model.Product;
import com.wms.model.Transaction;
import com.wms.model.Supplier;
import com.wms.model.TransactionType;
import com.wms.util.Validator;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Service {
    private final ProductDAO productDAO;
    private final SupplierDAO supplierDAO;
    private final InventoryDAO inventoryDAO;
    private final TransactionDAO transactionDAO;

    // Constructor usage: the service is wired with DAO dependencies.
    public Service(ProductDAO productDAO, SupplierDAO supplierDAO,
                            InventoryDAO inventoryDAO, TransactionDAO transactionDAO) {
        this.productDAO = productDAO;
        this.supplierDAO = supplierDAO;
        this.inventoryDAO = inventoryDAO;
        this.transactionDAO = transactionDAO;
    }

    public void addProduct(Product product) throws SQLException {
        validateProduct(product);
        productDAO.add(product);
    }

    public List<Product> getAllProducts() throws SQLException {
        return productDAO.getAll();
    }

    public Optional<Product> getProductById(int productId) throws SQLException {
        return productDAO.getById(productId);
    }

    public void updateProduct(Product product) throws SQLException {
        validateProduct(product);
        productDAO.update(product);
    }

    public void deleteProduct(int productId) throws SQLException {
        inventoryDAO.deleteByProductId(productId);
        productDAO.delete(productId);
    }

    public List<Product> searchProductsByName(String keyword) throws SQLException {
        return productDAO.searchByName(keyword);
    }

    public List<Product> searchProducts(String name, String category) throws SQLException {
        String nameKey = name == null ? "" : name.trim().toLowerCase();
        String categoryKey = category == null ? "" : category.trim().toLowerCase();

        List<Product> allProducts = productDAO.getAll();
        List<Product> filtered = new ArrayList<>();
        for (Product p : allProducts) {
            boolean matchName = nameKey.isBlank() || p.getName().toLowerCase().contains(nameKey);
            boolean matchCategory = categoryKey.isBlank() || p.getCategory().toLowerCase().contains(categoryKey);
            if (matchName && matchCategory) {
                filtered.add(p);
            }
        }
        return filtered;
    }

    public void addSupplier(Supplier supplier) throws SQLException {
        validateSupplier(supplier);
        supplierDAO.add(supplier);
    }

    public List<Supplier> getAllSuppliers() throws SQLException {
        return supplierDAO.getAll();
    }

    public Optional<Supplier> getSupplierById(int supplierId) throws SQLException {
        return supplierDAO.getById(supplierId);
    }

    public void updateSupplier(Supplier supplier) throws SQLException {
        validateSupplier(supplier);
        supplierDAO.update(supplier);
    }

    public void deleteSupplier(int supplierId) throws SQLException {
        supplierDAO.delete(supplierId);
    }

    public List<Supplier> searchSuppliersByName(String keyword) throws SQLException {
        return supplierDAO.searchByName(keyword);
    }

    public List<Inventory> getAllInventory() throws SQLException {
        return inventoryDAO.getAll();
    }

    // Method overloading: same name, different parameters for stock entry.
    public void addStock(int productId, int quantity, String location) throws SQLException {
        addStock(productId, null, quantity, location);
    }

    public void addStock(int productId, Integer supplierId, int quantity, String location) throws SQLException {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity should be greater than zero");
        }
        if (!Validator.isValidLocation(location)) {
            throw new IllegalArgumentException("Warehouse location must be like A1, B2, C10");
        }

        Optional<Inventory> existing = inventoryDAO.getByProductId(productId);
        int newQty;
        if (existing.isPresent()) {
            newQty = existing.get().getQuantityAvailable() + quantity;
            inventoryDAO.updateQuantity(productId, newQty);
        } else {
            newQty = quantity;
            inventoryDAO.add(new Inventory(0, productId, quantity, location));
        }

        transactionDAO.add(new Transaction(
                0,
                productId,
                supplierId,
                TransactionType.IN,
                quantity,
                LocalDateTime.now()
        ));
    }

    public void removeStock(int productId, int quantity) throws SQLException {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity should be greater than zero");
        }

        Inventory record = inventoryDAO.getByProductId(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product does not exist in inventory"));

        if (record.getQuantityAvailable() < quantity) {
            throw new IllegalArgumentException("Insufficient stock available");
        }

        int newQty = record.getQuantityAvailable() - quantity;
        inventoryDAO.updateQuantity(productId, newQty);

        transactionDAO.add(new Transaction(
                0,
                productId,
                null,
                TransactionType.OUT,
                quantity,
                LocalDateTime.now()
        ));
    }

    public List<Transaction> getAllTransactions() throws SQLException {
        return transactionDAO.getAll();
    }

    public String exportInventoryReportCsv(String fileName) throws Exception {
        List<Inventory> inventoryList = inventoryDAO.getAll();
        // Collections: HashMap gives fast product lookup by ID.
        Map<Integer, Product> productMap = new HashMap<>();
        for (Product product : productDAO.getAll()) {
            productMap.put(product.getId(), product);
        }

        StringBuilder csv = new StringBuilder();
        csv.append("InventoryId,ProductId,ProductName,Category,Quantity,Location,ReorderLevel\n");
        for (Inventory inv : inventoryList) {
            Product p = productMap.get(inv.getProductId());
            if (p == null) {
                continue;
            }
            csv.append(inv.getInventoryId()).append(",")
                    .append(inv.getProductId()).append(",")
                    .append(p.getName()).append(",")
                    .append(p.getCategory()).append(",")
                    .append(inv.getQuantityAvailable()).append(",")
                    .append(inv.getWarehouseLocation()).append(",")
                    .append(p.getReorderLevel()).append("\n");
        }

        Path output = Paths.get(fileName).toAbsolutePath();
        Files.writeString(output, csv.toString());
        return output.toString();
    }

    public Map<Integer, Integer> generateCurrentStockMap() throws SQLException {
        // Collections: HashMap stores current stock quantities by product ID.
        Map<Integer, Integer> stockMap = new HashMap<>();
        for (Inventory record : inventoryDAO.getAll()) {
            stockMap.put(record.getProductId(), record.getQuantityAvailable());
        }
        return stockMap;
    }

    public List<Product> getLowStockProducts() throws SQLException {
        // Collections: ArrayList collects products that need reorder attention.
        List<Product> lowStockProducts = new ArrayList<>();
        Map<Integer, Integer> stockMap = generateCurrentStockMap();
        for (Product product : productDAO.getAll()) {
            int qty = stockMap.getOrDefault(product.getId(), 0);
            if (qty <= product.getReorderLevel()) {
                lowStockProducts.add(product);
            }
        }
        return lowStockProducts;
    }

    private void validateProduct(Product product) {
        Validator.requireNotBlank(product.getName(), "Product name is required");
        Validator.requireNotBlank(product.getCategory(), "Category is required");
        if (product.getUnitPrice() < 0) {
            throw new IllegalArgumentException("Unit price cannot be negative");
        }
        if (product.getReorderLevel() < 0) {
            throw new IllegalArgumentException("Reorder level cannot be negative");
        }
    }

    private void validateSupplier(Supplier supplier) {
        Validator.requireNotBlank(supplier.getName(), "Supplier name is required");
        Validator.requireNotBlank(supplier.getPhone(), "Supplier phone is required");
        Validator.requireNotBlank(supplier.getEmail(), "Supplier email is required");
        Validator.requireNotBlank(supplier.getAddress(), "Supplier address is required");
        if (!Validator.isValidPhone(supplier.getPhone())) {
            throw new IllegalArgumentException("Supplier phone must have 10 digits");
        }
        if (!Validator.isValidEmail(supplier.getEmail())) {
            throw new IllegalArgumentException("Supplier email format is invalid");
        }
    }
}
