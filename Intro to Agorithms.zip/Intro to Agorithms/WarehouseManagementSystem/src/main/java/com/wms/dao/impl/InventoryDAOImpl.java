package com.wms.dao.impl;

import com.wms.dao.InventoryDAO;
import com.wms.model.Inventory;
import com.wms.util.DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InventoryDAOImpl implements InventoryDAO {

    @Override
    public void add(Inventory record) throws SQLException {
        String sql = "INSERT INTO inventory(product_id, quantity_available, warehouse_location) VALUES (?, ?, ?)";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, record.getProductId());
            statement.setInt(2, record.getQuantityAvailable());
            statement.setString(3, record.getWarehouseLocation());
            statement.executeUpdate();
        }
    }

    @Override
    public List<Inventory> getAll() throws SQLException {
        List<Inventory> records = new ArrayList<>();
        String sql = "SELECT inventory_id, product_id, quantity_available, warehouse_location FROM inventory ORDER BY inventory_id";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                records.add(map(resultSet));
            }
        }
        return records;
    }

    @Override
    public Optional<Inventory> getByProductId(int productId) throws SQLException {
        String sql = "SELECT inventory_id, product_id, quantity_available, warehouse_location FROM inventory WHERE product_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, productId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(map(resultSet));
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public void updateQuantity(int productId, int quantity) throws SQLException {
        String sql = "UPDATE inventory SET quantity_available = ? WHERE product_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, quantity);
            statement.setInt(2, productId);
            statement.executeUpdate();
        }
    }

    @Override
    public void deleteByProductId(int productId) throws SQLException {
        String sql = "DELETE FROM inventory WHERE product_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, productId);
            statement.executeUpdate();
        }
    }

    private Inventory map(ResultSet resultSet) throws SQLException {
        return new Inventory(
                resultSet.getInt("inventory_id"),
                resultSet.getInt("product_id"),
                resultSet.getInt("quantity_available"),
                resultSet.getString("warehouse_location")
        );
    }
}
