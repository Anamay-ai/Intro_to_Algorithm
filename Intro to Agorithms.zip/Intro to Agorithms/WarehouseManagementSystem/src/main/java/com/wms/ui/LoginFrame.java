package com.wms.ui;

import com.wms.auth.AuthService;
import com.wms.model.User;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.Optional;

public class LoginFrame extends JFrame {
    private static final Color PAGE_BG = new Color(246, 248, 251);
    private static final Color CARD_BG = new Color(255, 255, 255);
    private static final Color TITLE_COLOR = new Color(31, 41, 55);
    private static final Color MUTED_TEXT = new Color(102, 112, 120);
    private static final Color BUTTON_BG = new Color(211, 47, 47);
    private static final Color BUTTON_TEXT = new Color(255, 255, 255);

    public LoginFrame(AuthService authService, Menu menu) {
        setTitle("Warehouse Management");
        setSize(920, 560);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        styleTextField(usernameField);
        styleTextField(passwordField);
        styleButton(loginButton);

        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(PAGE_BG);
        page.setBorder(BorderFactory.createEmptyBorder(28, 28, 28, 28));

        JPanel card = new JPanel();
        card.setBackground(CARD_BG);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(228, 233, 240)),
            BorderFactory.createEmptyBorder(24, 26, 24, 26)
        ));

        JLabel heading = new JLabel("Warehouse Login");
        heading.setFont(new Font("Helvetica Neue", Font.BOLD, 24));
        heading.setForeground(TITLE_COLOR);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel("Sign in to manage inventory, stock movement, and reports");
        subtitle.setFont(new Font("Helvetica Neue", Font.PLAIN, 14));
        subtitle.setForeground(MUTED_TEXT);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel formPanel = new JPanel(new GridLayout(4, 1, 0, 10));
        formPanel.setBackground(CARD_BG);
        formPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel userLabel = new JLabel("Username");
        userLabel.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        userLabel.setForeground(TITLE_COLOR);

        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        passLabel.setForeground(TITLE_COLOR);

        formPanel.add(userLabel);
        formPanel.add(usernameField);
        formPanel.add(passLabel);
        formPanel.add(passwordField);

        JPanel buttonPanel = new JPanel(new BorderLayout());
        buttonPanel.setBackground(CARD_BG);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttonPanel.add(loginButton, BorderLayout.CENTER);

        card.add(heading);
        card.add(Box.createRigidArea(new Dimension(0, 6)));
        card.add(subtitle);
        card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(formPanel);
        card.add(Box.createRigidArea(new Dimension(0, 18)));
        card.add(buttonPanel);

        page.add(card, BorderLayout.CENTER);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            try {
                Optional<User> user = authService.login(username, password);
                if (user.isPresent()) {
                    dispose();
                    SwingUtilities.invokeLater(() -> new DashboardFrame(menu, user.get(), authService).setVisible(true));
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid username/password", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        setContentPane(page);
    }

    private void styleTextField(javax.swing.JComponent field) {
        field.setPreferredSize(new Dimension(260, 34));
        field.setFont(new Font("Helvetica Neue", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 217, 226)),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("Helvetica Neue", Font.BOLD, 14));
        button.setBackground(BUTTON_BG);
        button.setForeground(BUTTON_TEXT);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        button.setOpaque(true);
    }
}
