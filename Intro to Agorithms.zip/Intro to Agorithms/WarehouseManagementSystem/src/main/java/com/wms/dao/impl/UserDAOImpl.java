package com.wms.dao.impl;

import com.wms.dao.UserDAO;
import com.wms.model.Role;
import com.wms.model.User;
import com.wms.util.DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class UserDAOImpl implements UserDAO {

    @Override
    public Optional<User> findByUsername(String username) throws SQLException {
        String sql = "SELECT user_id, username, password, role FROM users WHERE username = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(new User(
                            resultSet.getInt("user_id"),
                            resultSet.getString("username"),
                            resultSet.getString("password"),
                            Role.valueOf(resultSet.getString("role"))
                    ));
                }
            }
        }
        return Optional.empty();
    }
}
