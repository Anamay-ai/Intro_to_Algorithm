package com.wms.dao;

import com.wms.model.Product;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface ProductDAO {
    void add(Product product) throws SQLException;

    List<Product> getAll() throws SQLException;

    Optional<Product> getById(int productId) throws SQLException;

    void update(Product product) throws SQLException;

    void delete(int productId) throws SQLException;

    List<Product> searchByName(String keyword) throws SQLException;
}
