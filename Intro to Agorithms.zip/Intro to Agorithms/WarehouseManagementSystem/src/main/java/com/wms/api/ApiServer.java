package com.wms.api;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import com.wms.model.Product;
import com.wms.service.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ApiServer {
    private final Service service;

    public ApiServer(Service service) {
        this.service = service;
    }

    public void start(int port) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/api/health", this::handleHealth);
        server.createContext("/api/products", this::handleProducts);
        server.createContext("/api/products/search", this::handleSearchProducts);
        server.setExecutor(null);
        server.start();
        System.out.println("REST API started on http://localhost:" + port);
    }

    private void handleHealth(HttpExchange exchange) throws IOException {
        sendJson(exchange, 200, "{\"status\":\"UP\"}");
    }

    private void handleProducts(HttpExchange exchange) throws IOException {
        if (!"GET".equals(exchange.getRequestMethod())) {
            sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
            return;
        }
        try {
            List<Product> products = service.getAllProducts();
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < products.size(); i++) {
                Product p = products.get(i);
                json.append("{\"id\":").append(p.getId())
                        .append(",\"name\":\"").append(escapeJson(p.getName())).append("\"")
                        .append(",\"category\":\"").append(escapeJson(p.getCategory())).append("\"")
                        .append(",\"unitPrice\":").append(p.getUnitPrice())
                        .append(",\"reorderLevel\":").append(p.getReorderLevel())
                        .append("}");
                if (i < products.size() - 1) {
                    json.append(",");
                }
            }
            json.append("]");
            sendJson(exchange, 200, json.toString());
        } catch (SQLException e) {
            sendJson(exchange, 500, "{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    private void handleSearchProducts(HttpExchange exchange) throws IOException {
        if (!"GET".equals(exchange.getRequestMethod())) {
            sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
            return;
        }
        try {
            Map<String, String> query = splitQuery(exchange.getRequestURI().getRawQuery());
            String name = query.getOrDefault("name", "");
            String category = query.getOrDefault("category", "");
            List<Product> products = service.searchProducts(name, category);
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < products.size(); i++) {
                Product p = products.get(i);
                json.append("{\"id\":").append(p.getId())
                        .append(",\"name\":\"").append(escapeJson(p.getName())).append("\"")
                        .append(",\"category\":\"").append(escapeJson(p.getCategory())).append("\"")
                        .append(",\"unitPrice\":").append(p.getUnitPrice())
                        .append(",\"reorderLevel\":").append(p.getReorderLevel())
                        .append("}");
                if (i < products.size() - 1) {
                    json.append(",");
                }
            }
            json.append("]");
            sendJson(exchange, 200, json.toString());
        } catch (SQLException e) {
            sendJson(exchange, 500, "{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        }
    }

    private void sendJson(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private Map<String, String> splitQuery(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isBlank()) {
            return map;
        }
        String[] pairs = query.split("&");
        for (String pair : pairs) {
            String[] kv = pair.split("=", 2);
            String key = URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
            String value = kv.length > 1 ? URLDecoder.decode(kv[1], StandardCharsets.UTF_8) : "";
            map.put(key, value);
        }
        return map;
    }

    private String escapeJson(String input) {
        return input == null ? "" : input.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
