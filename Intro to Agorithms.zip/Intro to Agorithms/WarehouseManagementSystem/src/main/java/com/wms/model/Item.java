package com.wms.model;

// Abstract class shared by all warehouse items.
public abstract class Item {
    // Encapsulation: these fields stay private and are accessed through getters and setters.
    private int id;
    private String name;

    // Constructor usage: default constructor for frameworks and object creation.
    protected Item() {
    }

    // Constructor usage: initializes the shared Item state.
    protected Item(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public abstract String getDisplayInfo();
}
