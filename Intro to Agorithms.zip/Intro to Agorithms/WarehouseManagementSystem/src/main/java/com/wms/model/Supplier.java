package com.wms.model;

public class Supplier extends Person {
    private String address;

    public Supplier() {
    }

    public Supplier(int id, String name, String phone, String email, String address) {
        super(id, name, phone, email);
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String getContactSummary() {
        return super.getContactSummary() + ", Address: " + address;
    }
}
