package com.wms.model;

// Inheritance: Supplier reuses the common Person fields and behaviour.
public class Supplier extends Person {
    private String address;

    public Supplier() {
    }

    // Constructor usage: initializes the inherited Person state plus supplier address.
    public Supplier(int id, String name, String phone, String email, String address) {
        super(id, name, phone, email);
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Method overriding: Supplier extends the contact summary with address.
    @Override
    public String getContactSummary() {
        return super.getContactSummary() + ", Address: " + address;
    }
}
