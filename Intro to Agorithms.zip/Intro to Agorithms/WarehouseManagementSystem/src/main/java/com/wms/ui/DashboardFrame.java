package com.wms.ui;

import com.wms.auth.AuthService;
import com.wms.model.Product;
import com.wms.model.Role;
import com.wms.model.User;
import com.wms.service.Service;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.List;

public class DashboardFrame extends JFrame {
    private static final Color PAGE_BG = new Color(243, 246, 250);
    private static final Color CARD_BG = new Color(255, 255, 255);
    private static final Color HEADER_BG = new Color(18, 26, 38);
    private static final Color HEADER_TEXT = new Color(236, 242, 248);
    private static final Color TEXT_MAIN = new Color(35, 42, 55);
    private static final Color ACTION_PRIMARY = new Color(26, 115, 232);
    private static final Color ACTION_DANGER = new Color(183, 28, 28);
    private static final Color ACTION_NEUTRAL = new Color(69, 90, 100);

    private final Service service;
    private final DefaultTableModel model;
    private final Menu menu;
    private final AuthService authService;

    public DashboardFrame(Menu menu, User user, AuthService authService) {
        this.menu = menu;
        this.authService = authService;
        this.service = menu.getService();

        setTitle("Warehouse Dashboard - " + user.getUsername() + " (" + user.getRole() + ")");
        setSize(1100, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel top = new JPanel(new GridLayout(2, 1, 0, 10));
        top.setOpaque(false);

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchRow.setOpaque(false);

        JLabel nameLabel = new JLabel("Search Name");
        styleLabel(nameLabel);
        searchRow.add(nameLabel);
        JTextField nameField = new JTextField(12);
        styleInput(nameField);
        searchRow.add(nameField);

        JLabel categoryLabel = new JLabel("Category");
        styleLabel(categoryLabel);
        searchRow.add(categoryLabel);
        JTextField categoryField = new JTextField(10);
        styleInput(categoryField);
        searchRow.add(categoryField);

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actionRow.setOpaque(false);

        JButton searchButton = new JButton("Search");
        JButton refreshButton = new JButton("Refresh");
        JButton lowStockButton = new JButton("Low Stock");
        JButton addButton = new JButton("Add Product");
        JButton deleteButton = new JButton("Delete Product");
        JButton exportButton = new JButton("Export CSV Report");

        styleActionButton(searchButton, ACTION_PRIMARY);
        styleActionButton(refreshButton, ACTION_NEUTRAL);
        styleActionButton(lowStockButton, new Color(0, 121, 107));
        styleActionButton(addButton, new Color(46, 125, 50));
        styleActionButton(deleteButton, ACTION_DANGER);
        styleActionButton(exportButton, new Color(94, 53, 177));

        actionRow.add(searchButton);
        actionRow.add(refreshButton);
        actionRow.add(lowStockButton);
        actionRow.add(addButton);
        actionRow.add(deleteButton);
        actionRow.add(exportButton);

        top.add(searchRow);
        top.add(actionRow);

        model = new DefaultTableModel(new String[]{"ID", "Name", "Category", "Price", "Reorder"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
    styleTable(table);
        JScrollPane tableScroll = new JScrollPane(table);
    tableScroll.setBorder(BorderFactory.createLineBorder(new Color(214, 222, 233)));

    JPanel header = createHeader(user);

    JPanel contentCard = new JPanel(new BorderLayout(0, 14));
    contentCard.setBackground(CARD_BG);
    contentCard.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createLineBorder(new Color(220, 226, 235)),
        BorderFactory.createEmptyBorder(16, 16, 16, 16)
    ));
    contentCard.add(top, BorderLayout.NORTH);
    contentCard.add(tableScroll, BorderLayout.CENTER);

    JPanel root = new JPanel(new BorderLayout(0, 14));
    root.setBackground(PAGE_BG);
    root.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
    root.add(header, BorderLayout.NORTH);
    root.add(contentCard, BorderLayout.CENTER);

        if (user.getRole() == Role.STAFF) {
            addButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }

        searchButton.addActionListener(e -> {
            try {
                loadProducts(service.searchProducts(nameField.getText(), categoryField.getText()));
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        refreshButton.addActionListener(e -> {
            try {
                loadProducts(service.getAllProducts());
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        lowStockButton.addActionListener(e -> {
            try {
                loadProducts(service.getLowStockProducts());
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        addButton.addActionListener(e -> addProductDialog());

        deleteButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select a product row first.");
                return;
            }
            int id = Integer.parseInt(model.getValueAt(row, 0).toString());
            try {
                service.deleteProduct(id);
                loadProducts(service.getAllProducts());
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        exportButton.addActionListener(e -> {
            try {
                String path = service.exportInventoryReportCsv("inventory-report.csv");
                JOptionPane.showMessageDialog(this, "Report generated: " + path);
            } catch (Exception ex) {
                showError(ex);
            }
        });

        setContentPane(root);
        try {
            loadProducts(service.getAllProducts());
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void addProductDialog() {
        JTextField nameField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField reorderField = new JTextField();

        styleInput(nameField);
        styleInput(categoryField);
        styleInput(priceField);
        styleInput(reorderField);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(formLabel("Name"));
        panel.add(nameField);
        panel.add(formLabel("Category"));
        panel.add(categoryField);
        panel.add(formLabel("Price"));
        panel.add(priceField);
        panel.add(formLabel("Reorder Level"));
        panel.add(reorderField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Product", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                Product product = new Product(0,
                        nameField.getText().trim(),
                        categoryField.getText().trim(),
                        Double.parseDouble(priceField.getText().trim()),
                        Integer.parseInt(reorderField.getText().trim()));
                service.addProduct(product);
                loadProducts(service.getAllProducts());
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void loadProducts(List<Product> products) {
        model.setRowCount(0);
        for (Product p : products) {
            model.addRow(new Object[]{p.getId(), p.getName(), p.getCategory(), p.getUnitPrice(), p.getReorderLevel()});
        }
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    private JPanel createHeader(User user) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(HEADER_BG);
        header.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        JLabel title = new JLabel("Warehouse Control Panel");
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 22));
        title.setForeground(HEADER_TEXT);

        JLabel subtitle = new JLabel("User: " + user.getUsername() + "   Role: " + user.getRole());
        subtitle.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        subtitle.setForeground(new Color(189, 201, 217));
        subtitle.setHorizontalAlignment(SwingConstants.RIGHT);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Helvetica Neue", Font.BOLD, 12));
        logoutButton.setFocusPainted(false);
        logoutButton.setBackground(new Color(244, 67, 54));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setBorder(BorderFactory.createEmptyBorder(7, 12, 7, 12));
        logoutButton.setOpaque(true);
        logoutButton.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame(authService, menu).setVisible(true));
        });

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(subtitle);
        rightPanel.add(logoutButton);

        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private void styleInput(JTextField field) {
        field.setFont(new Font("Helvetica Neue", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 32));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225)),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
    }

    private void styleLabel(JLabel label) {
        label.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        label.setForeground(TEXT_MAIN);
    }

    private JLabel formLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        label.setForeground(TEXT_MAIN);
        label.setBorder(BorderFactory.createEmptyBorder(8, 0, 3, 0));
        return label;
    }

    private void styleActionButton(JButton button, Color color) {
        button.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setOpaque(true);
        button.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Helvetica Neue", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(232, 238, 246));
        table.getTableHeader().setForeground(new Color(49, 64, 84));
        table.setSelectionBackground(new Color(216, 233, 255));
        table.setSelectionForeground(new Color(20, 35, 55));
        table.setGridColor(new Color(229, 235, 243));
        table.setShowVerticalLines(false);
        UIManager.put("Table.showHorizontalLines", Boolean.TRUE);
    }
}
