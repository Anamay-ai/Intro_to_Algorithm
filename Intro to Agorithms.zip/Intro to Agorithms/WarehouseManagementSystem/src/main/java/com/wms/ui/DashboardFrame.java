package com.wms.ui;

import com.wms.model.Product;
import com.wms.model.Role;
import com.wms.model.User;
import com.wms.service.Service;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.sql.SQLException;
import java.util.List;

public class DashboardFrame extends JFrame {
    private final Service service;
    private final DefaultTableModel model;

    public DashboardFrame(Menu menu, User user) {
        this.service = menu.getService();

        setTitle("Warehouse Dashboard - " + user.getUsername() + " (" + user.getRole() + ")");
        setSize(900, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel top = new JPanel();
        top.add(new JLabel("Search Name:"));
        JTextField nameField = new JTextField(12);
        top.add(nameField);
        top.add(new JLabel("Category:"));
        JTextField categoryField = new JTextField(10);
        top.add(categoryField);

        JButton searchButton = new JButton("Search");
        JButton refreshButton = new JButton("Refresh");
        JButton lowStockButton = new JButton("Low Stock");
        JButton addButton = new JButton("Add Product");
        JButton deleteButton = new JButton("Delete Product");
        JButton exportButton = new JButton("Export CSV Report");

        top.add(searchButton);
        top.add(refreshButton);
        top.add(lowStockButton);
        top.add(addButton);
        top.add(deleteButton);
        top.add(exportButton);

        model = new DefaultTableModel(new String[]{"ID", "Name", "Category", "Price", "Reorder"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        JScrollPane tableScroll = new JScrollPane(table);

        JPanel root = new JPanel();
        root.setLayout(new BorderLayout());
        root.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        root.add(top, BorderLayout.NORTH);
        root.add(tableScroll, BorderLayout.CENTER);

        if (user.getRole() == Role.STAFF) {
            addButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }

        searchButton.addActionListener(e -> {
            try {
                loadProducts(service.searchProducts(nameField.getText(), categoryField.getText()));
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        refreshButton.addActionListener(e -> {
            try {
                loadProducts(service.getAllProducts());
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        lowStockButton.addActionListener(e -> {
            try {
                loadProducts(service.getLowStockProducts());
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        addButton.addActionListener(e -> addProductDialog());

        deleteButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select a product row first.");
                return;
            }
            int id = Integer.parseInt(model.getValueAt(row, 0).toString());
            try {
                service.deleteProduct(id);
                loadProducts(service.getAllProducts());
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        exportButton.addActionListener(e -> {
            try {
                String path = service.exportInventoryReportCsv("inventory-report.csv");
                JOptionPane.showMessageDialog(this, "Report generated: " + path);
            } catch (Exception ex) {
                showError(ex);
            }
        });

        setContentPane(root);
        try {
            loadProducts(service.getAllProducts());
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void addProductDialog() {
        JTextField nameField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField reorderField = new JTextField();

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(new JLabel("Name"));
        panel.add(nameField);
        panel.add(new JLabel("Category"));
        panel.add(categoryField);
        panel.add(new JLabel("Price"));
        panel.add(priceField);
        panel.add(new JLabel("Reorder Level"));
        panel.add(reorderField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Product", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                Product product = new Product(0,
                        nameField.getText().trim(),
                        categoryField.getText().trim(),
                        Double.parseDouble(priceField.getText().trim()),
                        Integer.parseInt(reorderField.getText().trim()));
                service.addProduct(product);
                loadProducts(service.getAllProducts());
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void loadProducts(List<Product> products) {
        model.setRowCount(0);
        for (Product p : products) {
            model.addRow(new Object[]{p.getId(), p.getName(), p.getCategory(), p.getUnitPrice(), p.getReorderLevel()});
        }
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
