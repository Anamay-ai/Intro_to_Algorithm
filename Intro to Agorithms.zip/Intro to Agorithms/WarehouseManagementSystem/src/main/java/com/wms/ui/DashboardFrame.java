package com.wms.ui;

import com.wms.auth.AuthService;
import com.wms.model.Product;
import com.wms.model.Role;
import com.wms.model.Transaction;
import com.wms.model.User;
import com.wms.service.Service;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Cursor;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.format.DateTimeFormatter;

public class DashboardFrame extends JFrame {
    private static final Color PAGE_BG = new Color(246, 248, 251);
    private static final Color CARD_BG = new Color(255, 255, 255);
    private static final Color HEADER_BG = new Color(255, 255, 255);
    private static final Color SIDEBAR_BG = new Color(43, 8, 16);
    private static final Color SIDEBAR_BORDER = new Color(68, 16, 29);
    private static final Color HEADER_TEXT = new Color(31, 41, 55);
    private static final Color TEXT_MAIN = new Color(35, 42, 55);
    private static final Color ACTION_PRIMARY = new Color(211, 47, 47);
    private static final Color ACTION_DANGER = new Color(176, 39, 39);
    private static final Color ACTION_NEUTRAL = new Color(69, 81, 96);
    private static final Color ACTION_SUCCESS = new Color(38, 125, 97);
    private static final Color ACTION_WARNING = new Color(198, 127, 35);
    private static final Color ACTION_INFO = new Color(86, 99, 113);
    private static final DateTimeFormatter MOVEMENT_FORMAT = DateTimeFormatter.ofPattern("dd MMM, HH:mm");

    private final Service service;
    private final DefaultTableModel model;
    private JTable productsTable;
    private final JLabel selectedProductLabel = new JLabel("Select a product to see details");
    private final JLabel selectedStockLabel = new JLabel("-");
    private final JLabel selectedStatusLabel = new JLabel("-");
    private final JPanel recentMovementsPanel = new JPanel();
    private final JPanel lowStockPanel = new JPanel();
    private final JLabel productCountLabel = new JLabel("0");
    private final JLabel lowStockCountLabel = new JLabel("0");
    private final JLabel supplierCountLabel = new JLabel("0");
    private final JLabel transactionCountLabel = new JLabel("0");
    private ViewMode currentViewMode = ViewMode.ALL;
    private String searchName = "";
    private String searchCategory = "";

    private enum ViewMode {
        ALL,
        SEARCH,
        LOW_STOCK
    }

    public DashboardFrame(Menu menu, User user, AuthService authService) {
        this.service = menu.getService();

        setTitle("Warehouse Dashboard - " + user.getUsername() + " (" + user.getRole() + ")");
        setSize(1280, 760);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton viewAllButton = new JButton("View All");
        JButton searchButton = new JButton("Search / Filter");
        JButton lowStockButton = new JButton("Low Stock / Reorder");
        JButton stockInButton = new JButton("Add Stock");
        JButton stockOutButton = new JButton("Reduce Stock");
        JButton reorderPlanButton = new JButton("Smart Reorder Plan");
        JButton addButton = new JButton("Add Product");
        JButton deleteButton = new JButton("Delete Product");
        JButton exportButton = new JButton("Export CSV Report");
        JButton logoutButton = new JButton("Logout");

        styleActionButton(viewAllButton, ACTION_NEUTRAL);
        styleActionButton(searchButton, ACTION_PRIMARY);
        styleActionButton(lowStockButton, ACTION_WARNING);
        styleActionButton(stockInButton, ACTION_SUCCESS);
        styleActionButton(stockOutButton, ACTION_DANGER);
        styleActionButton(reorderPlanButton, ACTION_INFO);
        styleActionButton(addButton, ACTION_PRIMARY);
        styleActionButton(deleteButton, ACTION_DANGER);
        styleActionButton(exportButton, ACTION_NEUTRAL);
        styleActionButton(logoutButton, new Color(52, 64, 80));

        JTextField nameField = new JTextField(12);
        JTextField categoryField = new JTextField(10);
        styleInput(nameField);
        styleInput(categoryField);

        JPanel sidebar = createSidebar(user, viewAllButton, searchButton, lowStockButton, stockInButton, stockOutButton, reorderPlanButton, addButton, deleteButton, exportButton, logoutButton);
        JPanel top = createSearchBar(nameField, categoryField, searchButton, viewAllButton, lowStockButton);

        JPanel statsPanel = createStatsPanel();
        JPanel overviewBanner = createOverviewBanner(user);

        model = new DefaultTableModel(new String[]{"ID", "Name", "Category", "Quantity", "Reorder", "Status", "Price"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        this.productsTable = table;
        styleTable(table);
        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setBorder(BorderFactory.createLineBorder(new Color(225, 230, 238)));

        JPanel detailsPanel = createDetailsPanel();
        JPanel activityPanel = createActivityPanel();
        JPanel alertPanel = createAlertPanel();

        JPanel header = createHeader(user);

        JPanel topSection = new JPanel();
        topSection.setLayout(new BoxLayout(topSection, BoxLayout.Y_AXIS));
        topSection.setOpaque(false);
        topSection.add(overviewBanner);
        topSection.add(Box.createRigidArea(new Dimension(0, 12)));
        topSection.add(statsPanel);
        topSection.add(Box.createRigidArea(new Dimension(0, 12)));
        topSection.add(top);

        JPanel contentCard = new JPanel(new BorderLayout(0, 14));
        contentCard.setBackground(CARD_BG);
        contentCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(226, 231, 239)),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));
        contentCard.add(topSection, BorderLayout.NORTH);
        contentCard.add(tableScroll, BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);
        center.add(contentCard, BorderLayout.CENTER);

        JPanel rightRail = new JPanel(new BorderLayout(0, 14));
        rightRail.setOpaque(false);
        rightRail.setPreferredSize(new Dimension(320, 0));
        rightRail.add(detailsPanel, BorderLayout.NORTH);
        rightRail.add(activityPanel, BorderLayout.CENTER);
        rightRail.add(alertPanel, BorderLayout.SOUTH);

        JPanel root = new JPanel(new BorderLayout(14, 14));
        root.setBackground(PAGE_BG);
        root.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        root.add(header, BorderLayout.NORTH);
        root.add(sidebar, BorderLayout.WEST);
        root.add(center, BorderLayout.CENTER);
        root.add(rightRail, BorderLayout.EAST);

        if (user.getRole() == Role.STAFF) {
            addButton.setVisible(false);
            deleteButton.setVisible(false);
            exportButton.setVisible(false);
        }

        viewAllButton.addActionListener(e -> {
            try {
                currentViewMode = ViewMode.ALL;
                loadCurrentView();
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        searchButton.addActionListener(e -> {
            try {
                currentViewMode = ViewMode.SEARCH;
                searchName = nameField.getText();
                searchCategory = categoryField.getText();
                loadCurrentView();
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        lowStockButton.addActionListener(e -> {
            try {
                currentViewMode = ViewMode.LOW_STOCK;
                loadCurrentView();
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        stockInButton.addActionListener(e -> addStockDialog());
        stockOutButton.addActionListener(e -> reduceStockDialog());
        reorderPlanButton.addActionListener(e -> showReorderPlanDialog());
        addButton.addActionListener(e -> addProductDialog());

        deleteButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select a product row first.");
                return;
            }
            int id = Integer.parseInt(model.getValueAt(row, 0).toString());
            try {
                service.deleteProduct(id);
                loadCurrentView();
            } catch (SQLException ex) {
                showError(ex);
            }
        });

        exportButton.addActionListener(e -> {
            try {
                String path = service.exportInventoryReportCsv("inventory-report.csv");
                JOptionPane.showMessageDialog(this, "Report generated: " + path);
            } catch (Exception ex) {
                showError(ex);
            }
        });

        logoutButton.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame(authService, menu).setVisible(true));
        });

        setContentPane(root);
        try {
            loadCurrentView();
        } catch (SQLException e) {
            showError(e);
        }

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updateSelectedProductPanel();
            }
        });
    }

    private void addProductDialog() {
        JTextField nameField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField reorderField = new JTextField();

        styleInput(nameField);
        styleInput(categoryField);
        styleInput(priceField);
        styleInput(reorderField);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(formLabel("Name"));
        panel.add(nameField);
        panel.add(formLabel("Category"));
        panel.add(categoryField);
        panel.add(formLabel("Price"));
        panel.add(priceField);
        panel.add(formLabel("Reorder Level"));
        panel.add(reorderField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Product", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                Product product = new Product(0,
                        nameField.getText().trim(),
                        categoryField.getText().trim(),
                        Double.parseDouble(priceField.getText().trim()),
                        Integer.parseInt(reorderField.getText().trim()));
                service.addProduct(product);
                loadProducts(service.getAllProducts());
                refreshStats();
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void addStockDialog() {
        JTextField productIdField = new JTextField();
        JTextField supplierIdField = new JTextField();
        JTextField quantityField = new JTextField();
        JTextField locationField = new JTextField();

        styleInput(productIdField);
        styleInput(supplierIdField);
        styleInput(quantityField);
        styleInput(locationField);

        Integer selectedProductId = getSelectedProductId();
        if (selectedProductId != null) {
            productIdField.setText(String.valueOf(selectedProductId));
        }

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(formLabel("Product ID"));
        panel.add(productIdField);
        panel.add(formLabel("Supplier ID (optional)"));
        panel.add(supplierIdField);
        panel.add(formLabel("Quantity to Add"));
        panel.add(quantityField);
        panel.add(formLabel("Warehouse Location"));
        panel.add(locationField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Stock", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                int productId = Integer.parseInt(productIdField.getText().trim());
                int quantity = Integer.parseInt(quantityField.getText().trim());
                String location = locationField.getText().trim();
                String supplierText = supplierIdField.getText().trim();
                if (supplierText.isBlank()) {
                    service.addStock(productId, quantity, location);
                } else {
                    service.addStock(productId, Integer.parseInt(supplierText), quantity, location);
                }
                loadCurrentView();
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void reduceStockDialog() {
        JTextField productIdField = new JTextField();
        JTextField quantityField = new JTextField();

        styleInput(productIdField);
        styleInput(quantityField);

        Integer selectedProductId = getSelectedProductId();
        if (selectedProductId != null) {
            productIdField.setText(String.valueOf(selectedProductId));
        }

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(formLabel("Product ID"));
        panel.add(productIdField);
        panel.add(formLabel("Quantity to Reduce"));
        panel.add(quantityField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Reduce Stock", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                int productId = Integer.parseInt(productIdField.getText().trim());
                int quantity = Integer.parseInt(quantityField.getText().trim());
                service.removeStock(productId, quantity);
                loadCurrentView();
                JOptionPane.showMessageDialog(this, "Stock reduced. Low stock list updated.");
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void loadCurrentView() throws SQLException {
        if (currentViewMode == ViewMode.SEARCH) {
            loadProducts(service.searchProducts(searchName, searchCategory));
        } else if (currentViewMode == ViewMode.LOW_STOCK) {
            loadProducts(service.getLowStockProducts());
        } else {
            loadProducts(service.getAllProducts());
        }
        refreshStats();
        refreshActivity();
        updateSelectedProductPanel();
    }

    private void loadProducts(List<Product> products) {
        Map<Integer, Integer> stockMap;
        try {
            stockMap = service.generateCurrentStockMap();
        } catch (SQLException e) {
            showError(e);
            return;
        }

        model.setRowCount(0);
        for (Product p : products) {
            int qty = stockMap.getOrDefault(p.getId(), 0);
            String status = buildStockStatus(qty, p.getReorderLevel());
            model.addRow(new Object[]{
                    p.getId(),
                    p.getName(),
                    p.getCategory(),
                    qty,
                    p.getReorderLevel(),
                    status,
                    p.getUnitPrice()
            });
        }
    }

    private void updateSelectedProductPanel() {
        if (productsTable == null || productsTable.getSelectedRow() < 0) {
            selectedProductLabel.setText("Select a product to see details");
            selectedStockLabel.setText("-");
            selectedStatusLabel.setText("-");
            return;
        }
        int row = productsTable.getSelectedRow();
        String name = String.valueOf(model.getValueAt(row, 1));
        String category = String.valueOf(model.getValueAt(row, 2));
        String quantity = String.valueOf(model.getValueAt(row, 3));
        String reorder = String.valueOf(model.getValueAt(row, 4));
        String status = String.valueOf(model.getValueAt(row, 5));

        selectedProductLabel.setText(name + " • " + category + " • Reorder: " + reorder);
        selectedStockLabel.setText(quantity);
        selectedStatusLabel.setText(status);
    }

    private void refreshActivity() throws SQLException {
        recentMovementsPanel.removeAll();
        recentMovementsPanel.setLayout(new BoxLayout(recentMovementsPanel, BoxLayout.Y_AXIS));

        List<Transaction> transactions = service.getAllTransactions();
        int start = Math.max(0, transactions.size() - 6);

        if (transactions.isEmpty()) {
            recentMovementsPanel.add(emptyState("No stock movement yet"));
        } else {
            for (int i = transactions.size() - 1; i >= start; i--) {
                recentMovementsPanel.add(createMovementCard(transactions.get(i)));
                if (i > start) {
                    recentMovementsPanel.add(Box.createRigidArea(new Dimension(0, 8)));
                }
            }
        }

        recentMovementsPanel.revalidate();
        recentMovementsPanel.repaint();
        refreshLowStockPanel();
    }

    private String buildStockStatus(int qty, int reorderLevel) {
        if (qty <= reorderLevel) {
            return "LOW";
        }
        if (qty <= reorderLevel + 5) {
            return "MEDIUM";
        }
        return "HEALTHY";
    }

    private Integer getSelectedProductId() {
        if (productsTable == null) {
            return null;
        }
        int row = productsTable.getSelectedRow();
        if (row < 0) {
            return null;
        }
        return Integer.parseInt(model.getValueAt(row, 0).toString());
    }

    private void showReorderPlanDialog() {
        try {
            List<Product> lowStockProducts = service.getLowStockProducts();
            if (lowStockProducts.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All products are sufficiently stocked.", "Smart Reorder Plan", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            Map<Integer, Integer> stockMap = service.generateCurrentStockMap();
            DefaultTableModel reorderModel = new DefaultTableModel(
                    new String[]{"Product ID", "Name", "Current Qty", "Reorder Level", "Suggested Reorder"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            for (Product p : lowStockProducts) {
                int currentQty = stockMap.getOrDefault(p.getId(), 0);
                int suggested = Math.max((p.getReorderLevel() * 2) - currentQty, p.getReorderLevel());
                reorderModel.addRow(new Object[]{p.getId(), p.getName(), currentQty, p.getReorderLevel(), suggested});
            }

            JTable reorderTable = new JTable(reorderModel);
            reorderTable.setRowHeight(28);
            reorderTable.getTableHeader().setFont(new Font("Helvetica Neue", Font.BOLD, 13));
            reorderTable.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
            JScrollPane pane = new JScrollPane(reorderTable);
            pane.setPreferredSize(new Dimension(760, 300));
            JOptionPane.showMessageDialog(this, pane, "Smart Reorder Plan", JOptionPane.PLAIN_MESSAGE);
        } catch (Exception e) {
            showError(e);
        }
    }

    private void refreshStats() throws SQLException {
        productCountLabel.setText(String.valueOf(service.getAllProducts().size()));
        lowStockCountLabel.setText(String.valueOf(service.getLowStockProducts().size()));
        supplierCountLabel.setText(String.valueOf(service.getAllSuppliers().size()));
        transactionCountLabel.setText(String.valueOf(service.getAllTransactions().size()));
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    private JPanel createHeader(User user) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(HEADER_BG);
        header.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));

        JLabel title = new JLabel("Warehouse Control Panel");
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 22));
        title.setForeground(HEADER_TEXT);

        JLabel subtitle = new JLabel("User: " + user.getUsername() + "   Role: " + user.getRole());
        subtitle.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        subtitle.setForeground(new Color(189, 201, 217));
        subtitle.setHorizontalAlignment(SwingConstants.RIGHT);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(subtitle);

        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);
        return header;
    }

    private JPanel createSidebar(User user, JButton viewAllButton, JButton searchButton, JButton lowStockButton,
                                 JButton stockInButton, JButton stockOutButton, JButton reorderPlanButton, JButton addButton,
                                 JButton deleteButton, JButton exportButton, JButton logoutButton) {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBackground(SIDEBAR_BG);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(SIDEBAR_BORDER),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        JLabel title = new JLabel("Warehouse Menu");
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(LEFT_ALIGNMENT);

        JLabel role = new JLabel("Role: " + user.getRole());
        role.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        role.setForeground(new Color(190, 200, 213));
        role.setAlignmentX(LEFT_ALIGNMENT);

        sidebar.add(title);
        sidebar.add(Box.createRigidArea(new Dimension(0, 4)));
        sidebar.add(role);
        sidebar.add(Box.createRigidArea(new Dimension(0, 16)));

        styleSidebarButton(viewAllButton);
        sidebar.add(viewAllButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 8)));
        styleSidebarButton(searchButton);
        sidebar.add(searchButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 8)));
        styleSidebarButton(lowStockButton);
        sidebar.add(lowStockButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 12)));
        sidebar.add(createSidebarDivider());
        sidebar.add(Box.createRigidArea(new Dimension(0, 12)));

        styleSidebarButton(stockOutButton);
        sidebar.add(stockOutButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 8)));
        styleSidebarButton(reorderPlanButton);
        sidebar.add(reorderPlanButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 8)));
        styleSidebarButton(stockInButton);
        sidebar.add(stockInButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 12)));
        sidebar.add(createSidebarDivider());
        sidebar.add(Box.createRigidArea(new Dimension(0, 12)));

        styleSidebarButton(addButton);
        sidebar.add(addButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 8)));
        styleSidebarButton(deleteButton);
        sidebar.add(deleteButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 8)));
        styleSidebarButton(exportButton);
        sidebar.add(exportButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 12)));
        sidebar.add(createSidebarDivider());
        sidebar.add(Box.createRigidArea(new Dimension(0, 12)));
        sidebar.add(Box.createVerticalGlue());
        styleSidebarButton(logoutButton);
        sidebar.add(logoutButton);

        if (user.getRole() == Role.STAFF) {
            stockInButton.setVisible(false);
            addButton.setVisible(false);
            deleteButton.setVisible(false);
            exportButton.setVisible(false);
        }

        return sidebar;
    }

    private JPanel createSearchBar(JTextField nameField, JTextField categoryField, JButton searchButton,
                                   JButton viewAllButton, JButton lowStockButton) {
        JPanel wrapper = new JPanel(new BorderLayout(0, 10));
        wrapper.setOpaque(false);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        row.setOpaque(false);

        JLabel nameLabel = new JLabel("Search Name");
        styleLabel(nameLabel);
        JLabel categoryLabel = new JLabel("Category");
        styleLabel(categoryLabel);

        row.add(nameLabel);
        row.add(nameField);
        row.add(categoryLabel);
        row.add(categoryField);

        JPanel helper = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        helper.setOpaque(false);
        helper.add(searchButton);
        helper.add(viewAllButton);
        helper.add(lowStockButton);

        wrapper.add(row, BorderLayout.NORTH);
        wrapper.add(helper, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 12, 12));
        statsPanel.setOpaque(false);
        statsPanel.add(createStatCard("Products", productCountLabel, ACTION_PRIMARY));
        statsPanel.add(createStatCard("Low Stock", lowStockCountLabel, ACTION_DANGER));
        statsPanel.add(createStatCard("Suppliers", supplierCountLabel, ACTION_SUCCESS));
        statsPanel.add(createStatCard("Transactions", transactionCountLabel, ACTION_INFO));
        return statsPanel;
    }

    private JPanel createStatCard(String title, JLabel valueLabel, Color accent) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(228, 233, 240)),
                BorderFactory.createEmptyBorder(14, 14, 14, 14)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
        titleLabel.setForeground(new Color(99, 112, 130));

        valueLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 30));
        valueLabel.setForeground(accent);

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private JPanel createOverviewBanner(User user) {
        JPanel banner = new JPanel(new BorderLayout());
        banner.setBackground(CARD_BG);
        banner.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        JLabel title = new JLabel("Warehouse Operations Dashboard");
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 26));
        title.setForeground(TEXT_MAIN);

        JLabel subtitle = new JLabel("Manage stock, detect low inventory, and review recent movement in one place");
        subtitle.setFont(new Font("Helvetica Neue", Font.PLAIN, 14));
        subtitle.setForeground(new Color(100, 110, 120));

        JLabel roleTag = new JLabel("Logged in as " + user.getRole());
        roleTag.setFont(new Font("Helvetica Neue", Font.BOLD, 12));
        roleTag.setForeground(ACTION_PRIMARY.darker());
        roleTag.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(228, 173, 173)),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.add(title);
        left.add(Box.createRigidArea(new Dimension(0, 6)));
        left.add(subtitle);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setOpaque(false);
        right.add(roleTag);

        banner.add(left, BorderLayout.WEST);
        banner.add(right, BorderLayout.EAST);
        return banner;
    }

    private JPanel createDetailsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(228, 233, 240)),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        JLabel title = new JLabel("Selected Item");
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 16));
        title.setForeground(TEXT_MAIN);
        title.setAlignmentX(LEFT_ALIGNMENT);

        JLabel hint = new JLabel("Click a row to inspect stock status");
        hint.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        hint.setForeground(new Color(100, 110, 120));
        hint.setAlignmentX(LEFT_ALIGNMENT);

        JLabel product = selectedProductLabel;
        product.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        product.setForeground(TEXT_MAIN);
        product.setAlignmentX(LEFT_ALIGNMENT);
        product.setBorder(BorderFactory.createEmptyBorder(10, 0, 8, 0));

        JPanel stockRow = new JPanel(new GridLayout(1, 2, 10, 10));
        stockRow.setOpaque(false);
        stockRow.setAlignmentX(LEFT_ALIGNMENT);
        stockRow.add(detailTile("Current Qty", selectedStockLabel));
        stockRow.add(detailTile("Status", selectedStatusLabel));

        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 4)));
        panel.add(hint);
        panel.add(product);
        panel.add(stockRow);
        return panel;
    }

    private JPanel createActivityPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(228, 233, 240)),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        JLabel title = new JLabel("Activity Timeline");
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 16));
        title.setForeground(TEXT_MAIN);
        JLabel subtitle = new JLabel("Latest stock in/out events");
        subtitle.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        subtitle.setForeground(new Color(100, 110, 120));

        recentMovementsPanel.setOpaque(false);
        JScrollPane scroll = new JScrollPane(recentMovementsPanel);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(228, 233, 240)));
        scroll.getVerticalScrollBar().setUnitIncrement(12);
        scroll.setPreferredSize(new Dimension(280, 280));

        panel.add(title, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(subtitle, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createAlertPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(CARD_BG);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(228, 233, 240)),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        JLabel title = new JLabel("Low Stock Alerts");
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 16));
        title.setForeground(TEXT_MAIN);

        lowStockPanel.setLayout(new BoxLayout(lowStockPanel, BoxLayout.Y_AXIS));
        lowStockPanel.setOpaque(false);

        JScrollPane scroll = new JScrollPane(lowStockPanel);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(228, 233, 240)));
        scroll.getVerticalScrollBar().setUnitIncrement(12);
        scroll.setPreferredSize(new Dimension(280, 160));

        panel.add(title, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createMovementCard(Transaction transaction) {
        JPanel card = new JPanel(new BorderLayout(10, 4));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, transaction.getTransactionType().name().equals("IN") ? ACTION_SUCCESS : ACTION_DANGER),
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(228, 233, 240)),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)
            )
        ));

        Color accent = transaction.getTransactionType().name().equals("IN") ? ACTION_SUCCESS : ACTION_DANGER;

        JLabel badge = new JLabel(transaction.getTransactionType().name());
        badge.setOpaque(true);
        badge.setForeground(Color.WHITE);
        badge.setBackground(accent);
        badge.setFont(new Font("Helvetica Neue", Font.BOLD, 11));
        badge.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

        JLabel main = new JLabel((transaction.getTransactionType().name().equals("IN") ? "Received" : "Issued") + " stock for Product #" + transaction.getProductId());
        main.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
        main.setForeground(TEXT_MAIN);

        JLabel qty = new JLabel("Qty " + transaction.getQuantity());
        qty.setFont(new Font("Helvetica Neue", Font.BOLD, 12));
        qty.setForeground(accent);

        JLabel time = new JLabel(transaction.getTransactionDate() == null ? "" : transaction.getTransactionDate().format(MOVEMENT_FORMAT));
        time.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        time.setForeground(new Color(102, 112, 133));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(badge, BorderLayout.WEST);
        top.add(time, BorderLayout.EAST);

        JPanel centerBlock = new JPanel(new BorderLayout());
        centerBlock.setOpaque(false);
        centerBlock.add(main, BorderLayout.WEST);
        centerBlock.add(qty, BorderLayout.EAST);

        card.add(top, BorderLayout.NORTH);
        card.add(centerBlock, BorderLayout.SOUTH);
        return card;
    }

    private JPanel emptyState(String text) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        label.setForeground(new Color(100, 110, 120));
        panel.add(label, BorderLayout.CENTER);
        return panel;
    }

    private void refreshLowStockPanel() throws SQLException {
        lowStockPanel.removeAll();
        List<Product> lowStock = service.getLowStockProducts();
        Map<Integer, Integer> stockMap = service.generateCurrentStockMap();
        if (lowStock.isEmpty()) {
            lowStockPanel.add(emptyState("No low-stock products"));
        } else {
            for (Product product : lowStock) {
                int qty = stockMap.getOrDefault(product.getId(), 0);
                lowStockPanel.add(createLowStockChip(product.getName(), qty, product.getReorderLevel()));
                lowStockPanel.add(Box.createRigidArea(new Dimension(0, 8)));
            }
        }
        lowStockPanel.revalidate();
        lowStockPanel.repaint();
    }

    private JPanel createLowStockChip(String name, int qty, int reorderLevel) {
        JPanel chip = new JPanel(new BorderLayout());
        chip.setBackground(new Color(255, 247, 245));
        chip.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(245, 196, 196)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JLabel top = new JLabel(name);
        top.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
        top.setForeground(new Color(153, 35, 35));

        JLabel bottom = new JLabel("Qty " + qty + " / Reorder " + reorderLevel);
        bottom.setFont(new Font("Helvetica Neue", Font.PLAIN, 12));
        bottom.setForeground(new Color(160, 78, 27));

        chip.add(top, BorderLayout.NORTH);
        chip.add(bottom, BorderLayout.SOUTH);
        return chip;
    }

    private JPanel detailTile(String label, JLabel valueLabel) {
        JPanel tile = new JPanel(new BorderLayout());
        tile.setBackground(new Color(248, 250, 252));
        tile.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(228, 233, 240)),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JLabel title = new JLabel(label);
        title.setFont(new Font("Helvetica Neue", Font.BOLD, 12));
        title.setForeground(new Color(100, 110, 120));

        valueLabel.setFont(new Font("Helvetica Neue", Font.BOLD, 18));
        valueLabel.setForeground(TEXT_MAIN);

        tile.add(title, BorderLayout.NORTH);
        tile.add(valueLabel, BorderLayout.CENTER);
        return tile;
    }

    private void styleInput(JTextField field) {
        field.setFont(new Font("Helvetica Neue", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 32));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 217, 226)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
    }

    private void styleLabel(JLabel label) {
        label.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        label.setForeground(TEXT_MAIN);
    }

    private JLabel formLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        label.setForeground(TEXT_MAIN);
        label.setBorder(BorderFactory.createEmptyBorder(8, 0, 3, 0));
        return label;
    }

    private void styleActionButton(JButton button, Color color) {
        button.setFont(new Font("Helvetica Neue", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setOpaque(true);
        button.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        button.setAlignmentX(LEFT_ALIGNMENT);
    }

    private void styleSidebarButton(JButton button) {
        button.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        button.setFocusPainted(false);
        button.setForeground(Color.WHITE);
        button.setBackground(SIDEBAR_BG);
        button.setOpaque(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        button.setAlignmentX(LEFT_ALIGNMENT);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setOpaque(true);
                button.setContentAreaFilled(true);
                button.setBackground(new Color(57, 16, 26));
                button.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 3, 0, 0, new Color(222, 71, 71)),
                        BorderFactory.createEmptyBorder(10, 7, 10, 10)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setOpaque(false);
                button.setContentAreaFilled(false);
                button.setBackground(SIDEBAR_BG);
                button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            }
        });
    }

    private JPanel createSidebarDivider() {
        JPanel divider = new JPanel();
        divider.setBackground(new Color(72, 22, 34));
        divider.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        divider.setPreferredSize(new Dimension(Integer.MAX_VALUE, 1));
        divider.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        return divider;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(new Font("Helvetica Neue", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("Helvetica Neue", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(245, 247, 250));
        table.getTableHeader().setForeground(new Color(43, 52, 65));
        table.setSelectionBackground(new Color(255, 232, 232));
        table.setSelectionForeground(new Color(55, 20, 20));
        table.setGridColor(new Color(232, 237, 244));
        table.setShowVerticalLines(false);

        DefaultTableCellRenderer statusRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    String status = String.valueOf(value);
                    if ("LOW".equals(status)) {
                        c.setForeground(ACTION_DANGER);
                    } else if ("MEDIUM".equals(status)) {
                        c.setForeground(ACTION_WARNING);
                    } else {
                        c.setForeground(ACTION_SUCCESS);
                    }
                }
                return c;
            }
        };
        table.getColumnModel().getColumn(5).setCellRenderer(statusRenderer);
        UIManager.put("Table.showHorizontalLines", Boolean.TRUE);
    }
}
