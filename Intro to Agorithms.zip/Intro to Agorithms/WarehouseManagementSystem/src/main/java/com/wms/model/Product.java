package com.wms.model;

// Inheritance: Product extends the shared Item base class.
public class Product extends Item {
    private String category;
    private double unitPrice;
    private int reorderLevel;

    public Product() {
    }

    // Constructor usage: sets both Item fields and Product-specific fields.
    public Product(int id, String name, String category, double unitPrice, int reorderLevel) {
        super(id, name);
        this.category = category;
        this.unitPrice = unitPrice;
        this.reorderLevel = reorderLevel;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    // Method overloading: same method name, different parameter type.
    public void setUnitPrice(String unitPrice) {
        this.unitPrice = Double.parseDouble(unitPrice);
    }

    public int getReorderLevel() {
        return reorderLevel;
    }

    public void setReorderLevel(int reorderLevel) {
        this.reorderLevel = reorderLevel;
    }

    // Method overriding: Product defines its own display format.
    @Override
    public String getDisplayInfo() {
        return "Product ID: " + getId() + ", Name: " + getName() + ", Category: " + category
                + ", Unit Price: " + unitPrice + ", Reorder Level: " + reorderLevel;
    }
}
