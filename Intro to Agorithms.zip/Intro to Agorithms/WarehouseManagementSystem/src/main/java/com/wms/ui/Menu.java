package com.wms.ui;

import com.wms.model.Inventory;
import com.wms.model.Product;
import com.wms.model.Transaction;
import com.wms.model.Supplier;
import com.wms.service.Service;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Menu {
    private final Service warehouseService;
    private final Scanner scanner;

    public Menu(Service warehouseService) {
        this.warehouseService = warehouseService;
        this.scanner = new Scanner(System.in);
    }

    public Service getService() {
        return warehouseService;
    }

    public void start() {
        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Enter your choice: ");
            String input = scanner.nextLine().trim();

            try {
                switch (input) {
                    case "1" -> addProduct();
                    case "2" -> viewProducts();
                    case "3" -> updateProduct();
                    case "4" -> deleteProduct();
                    case "5" -> searchProduct();
                    case "6" -> addSupplier();
                    case "7" -> viewSuppliers();
                    case "8" -> updateSupplier();
                    case "9" -> deleteSupplier();
                    case "10" -> addStock();
                    case "11" -> removeStock();
                    case "12" -> viewInventory();
                    case "13" -> viewLowStockProducts();
                    case "14" -> viewTransactions();
                    case "0" -> running = false;
                    default -> System.out.println("Invalid choice. Try again.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Validation error: " + e.getMessage());
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
            System.out.println();
        }
        System.out.println("Thank you for using Warehouse Management System.");
    }

    private void printMenu() {
        System.out.println("================ Warehouse Management ================");
        System.out.println("1. Add Product");
        System.out.println("2. View Products");
        System.out.println("3. Update Product");
        System.out.println("4. Delete Product");
        System.out.println("5. Search Product");
        System.out.println("6. Add Supplier");
        System.out.println("7. View Suppliers");
        System.out.println("8. Update Supplier");
        System.out.println("9. Delete Supplier");
        System.out.println("10. Add Stock (IN)");
        System.out.println("11. Remove Stock (OUT)");
        System.out.println("12. View Inventory");
        System.out.println("13. View Low Stock Products");
        System.out.println("14. View Stock Transactions");
        System.out.println("0. Exit");
        System.out.println("======================================================");
    }

    private void addProduct() throws SQLException {
        System.out.print("Product name: ");
        String name = scanner.nextLine();
        System.out.print("Category: ");
        String category = scanner.nextLine();
        System.out.print("Unit price: ");
        double unitPrice = Double.parseDouble(scanner.nextLine());
        System.out.print("Reorder level: ");
        int reorderLevel = Integer.parseInt(scanner.nextLine());

        Product product = new Product(0, name, category, unitPrice, reorderLevel);
        warehouseService.addProduct(product);
        System.out.println("Product added successfully.");
    }

    private void viewProducts() throws SQLException {
        List<Product> products = warehouseService.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("No products found.");
            return;
        }
        products.forEach(p -> System.out.println(p.getDisplayInfo()));
    }

    private void updateProduct() throws SQLException {
        System.out.print("Product ID to update: ");
        int id = Integer.parseInt(scanner.nextLine());

        Product existing = warehouseService.getProductById(id)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        System.out.print("New name (" + existing.getName() + "): ");
        String name = scanner.nextLine();
        System.out.print("New category (" + existing.getCategory() + "): ");
        String category = scanner.nextLine();
        System.out.print("New unit price (" + existing.getUnitPrice() + "): ");
        String unitPrice = scanner.nextLine();
        System.out.print("New reorder level (" + existing.getReorderLevel() + "): ");
        String reorderLevel = scanner.nextLine();

        existing.setName(name.isBlank() ? existing.getName() : name);
        existing.setCategory(category.isBlank() ? existing.getCategory() : category);
        existing.setUnitPrice(unitPrice.isBlank() ? existing.getUnitPrice() : Double.parseDouble(unitPrice));
        existing.setReorderLevel(reorderLevel.isBlank() ? existing.getReorderLevel() : Integer.parseInt(reorderLevel));

        warehouseService.updateProduct(existing);
        System.out.println("Product updated successfully.");
    }

    private void deleteProduct() throws SQLException {
        System.out.print("Product ID to delete: ");
        int id = Integer.parseInt(scanner.nextLine());
        warehouseService.deleteProduct(id);
        System.out.println("Product deleted successfully.");
    }

    private void searchProduct() throws SQLException {
        System.out.print("Enter product name keyword: ");
        String keyword = scanner.nextLine();
        List<Product> products = warehouseService.searchProductsByName(keyword);
        if (products.isEmpty()) {
            System.out.println("No product found for keyword: " + keyword);
            return;
        }
        products.forEach(p -> System.out.println(p.getDisplayInfo()));
    }

    private void addSupplier() throws SQLException {
        System.out.print("Supplier name: ");
        String name = scanner.nextLine();
        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Address: ");
        String address = scanner.nextLine();

        Supplier supplier = new Supplier(0, name, phone, email, address);
        warehouseService.addSupplier(supplier);
        System.out.println("Supplier added successfully.");
    }

    private void viewSuppliers() throws SQLException {
        List<Supplier> suppliers = warehouseService.getAllSuppliers();
        if (suppliers.isEmpty()) {
            System.out.println("No suppliers found.");
            return;
        }
        suppliers.forEach(s -> System.out.println("Supplier ID: " + s.getId() + ", " + s.getContactSummary()));
    }

    private void updateSupplier() throws SQLException {
        System.out.print("Supplier ID to update: ");
        int id = Integer.parseInt(scanner.nextLine());

        Supplier existing = warehouseService.getSupplierById(id)
                .orElseThrow(() -> new IllegalArgumentException("Supplier not found"));

        System.out.print("New name (" + existing.getName() + "): ");
        String name = scanner.nextLine();
        System.out.print("New phone (" + existing.getPhone() + "): ");
        String phone = scanner.nextLine();
        System.out.print("New email (" + existing.getEmail() + "): ");
        String email = scanner.nextLine();
        System.out.print("New address (" + existing.getAddress() + "): ");
        String address = scanner.nextLine();

        existing.setName(name.isBlank() ? existing.getName() : name);
        existing.setPhone(phone.isBlank() ? existing.getPhone() : phone);
        existing.setEmail(email.isBlank() ? existing.getEmail() : email);
        existing.setAddress(address.isBlank() ? existing.getAddress() : address);

        warehouseService.updateSupplier(existing);
        System.out.println("Supplier updated successfully.");
    }

    private void deleteSupplier() throws SQLException {
        System.out.print("Supplier ID to delete: ");
        int id = Integer.parseInt(scanner.nextLine());
        warehouseService.deleteSupplier(id);
        System.out.println("Supplier deleted successfully.");
    }

    private void addStock() throws SQLException {
        System.out.print("Product ID: ");
        int productId = Integer.parseInt(scanner.nextLine());
        System.out.print("Supplier ID (optional, press Enter to skip): ");
        String supplierInput = scanner.nextLine();
        System.out.print("Quantity to add: ");
        int quantity = Integer.parseInt(scanner.nextLine());
        System.out.print("Warehouse location (e.g., A1): ");
        String location = scanner.nextLine();

        if (supplierInput.isBlank()) {
            warehouseService.addStock(productId, quantity, location);
        } else {
            warehouseService.addStock(productId, Integer.parseInt(supplierInput), quantity, location);
        }
        System.out.println("Stock added successfully.");
    }

    private void removeStock() throws SQLException {
        System.out.print("Product ID: ");
        int productId = Integer.parseInt(scanner.nextLine());
        System.out.print("Quantity to remove: ");
        int quantity = Integer.parseInt(scanner.nextLine());
        warehouseService.removeStock(productId, quantity);
        System.out.println("Stock removed successfully.");
    }

    private void viewInventory() throws SQLException {
        List<Inventory> records = warehouseService.getAllInventory();
        if (records.isEmpty()) {
            System.out.println("No inventory records found.");
            return;
        }
        records.forEach(System.out::println);
    }

    private void viewLowStockProducts() throws SQLException {
        List<Product> lowStockProducts = warehouseService.getLowStockProducts();
        if (lowStockProducts.isEmpty()) {
            System.out.println("No low stock products.");
            return;
        }
        System.out.println("Low stock products:");
        lowStockProducts.forEach(p -> System.out.println(p.getDisplayInfo()));
    }

    private void viewTransactions() throws SQLException {
        List<Transaction> transactions = warehouseService.getAllTransactions();
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }
        transactions.forEach(System.out::println);
    }
}
