package com.wms;

import com.wms.api.ApiServer;
import com.wms.auth.AuthService;
import com.wms.dao.InventoryDAO;
import com.wms.dao.ProductDAO;
import com.wms.dao.TransactionDAO;
import com.wms.dao.SupplierDAO;
import com.wms.dao.UserDAO;
import com.wms.dao.impl.InventoryDAOImpl;
import com.wms.dao.impl.ProductDAOImpl;
import com.wms.dao.impl.TransactionDAOImpl;
import com.wms.dao.impl.SupplierDAOImpl;
import com.wms.dao.impl.UserDAOImpl;
import com.wms.service.Service;
import com.wms.ui.LoginFrame;
import com.wms.ui.Menu;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Class and object creation: concrete DAO objects are created here.
        ProductDAO productDAO = new ProductDAOImpl();
        SupplierDAO supplierDAO = new SupplierDAOImpl();
        InventoryDAO inventoryDAO = new InventoryDAOImpl();
        TransactionDAO transactionDAO = new TransactionDAOImpl();
        UserDAO userDAO = new UserDAOImpl();

        // Constructor usage: Service is built with DAO dependencies.
        Service warehouseService = new Service(productDAO, supplierDAO, inventoryDAO, transactionDAO);
        Menu consoleUI = new Menu(warehouseService);

        String mode = args.length > 0 ? args[0].trim().toLowerCase() : "gui";

        if ("console".equals(mode)) {
            consoleUI.start();
            return;
        }

        if ("api".equals(mode)) {
            try {
                new ApiServer(warehouseService).start(8080);
            } catch (Exception e) {
                System.out.println("Failed to start API: " + e.getMessage());
            }
            return;
        }

        AuthService authService = new AuthService(userDAO);
        SwingUtilities.invokeLater(() -> new LoginFrame(authService, consoleUI).setVisible(true));
    }
}
