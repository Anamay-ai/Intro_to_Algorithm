package com.wms.dao.impl;

import com.wms.dao.ProductDAO;
import com.wms.model.Product;
import com.wms.util.DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductDAOImpl implements ProductDAO {

    @Override
    public void add(Product product) throws SQLException {
        String sql = "INSERT INTO products(name, category, unit_price, reorder_level) VALUES (?, ?, ?, ?)";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, product.getName());
            statement.setString(2, product.getCategory());
            statement.setDouble(3, product.getUnitPrice());
            statement.setInt(4, product.getReorderLevel());
            statement.executeUpdate();
        }
    }

    @Override
    public List<Product> getAll() throws SQLException {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT product_id, name, category, unit_price, reorder_level FROM products ORDER BY product_id";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                products.add(map(resultSet));
            }
        }
        return products;
    }

    @Override
    public Optional<Product> getById(int productId) throws SQLException {
        String sql = "SELECT product_id, name, category, unit_price, reorder_level FROM products WHERE product_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, productId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return Optional.of(map(resultSet));
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public void update(Product product) throws SQLException {
        String sql = "UPDATE products SET name = ?, category = ?, unit_price = ?, reorder_level = ? WHERE product_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, product.getName());
            statement.setString(2, product.getCategory());
            statement.setDouble(3, product.getUnitPrice());
            statement.setInt(4, product.getReorderLevel());
            statement.setInt(5, product.getId());
            statement.executeUpdate();
        }
    }

    @Override
    public void delete(int productId) throws SQLException {
        String sql = "DELETE FROM products WHERE product_id = ?";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, productId);
            statement.executeUpdate();
        }
    }

    @Override
    public List<Product> searchByName(String keyword) throws SQLException {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT product_id, name, category, unit_price, reorder_level FROM products WHERE LOWER(name) LIKE LOWER(?)";
        try (Connection connection = DB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "%" + keyword + "%");
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    products.add(map(resultSet));
                }
            }
        }
        return products;
    }

    private Product map(ResultSet resultSet) throws SQLException {
        return new Product(
                resultSet.getInt("product_id"),
                resultSet.getString("name"),
                resultSet.getString("category"),
                resultSet.getDouble("unit_price"),
                resultSet.getInt("reorder_level")
        );
    }
}
