package com.wms.dao;

import com.wms.model.User;

import java.sql.SQLException;
import java.util.Optional;

public interface UserDAO {
    Optional<User> findByUsername(String username) throws SQLException;
}
