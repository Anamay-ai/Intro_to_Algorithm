#!/usr/bin/env bash
set +e

# Stop app/API Maven Java processes for this project
pkill -f "maven.*WarehouseManagementSystem" 2>/dev/null
pkill -f "org.codehaus.plexus.classworlds.launcher.Launcher -q exec:java" 2>/dev/null

# Stop isolated MySQL 3307
pkill -f "mysqld_safe.*port=3307" 2>/dev/null
pkill -f "mysqld.*port=3307" 2>/dev/null

echo "Stopped project processes."
