#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"

NO_GUI=0
if [ "$1" = "--setup-only" ]; then
  NO_GUI=1
fi

# Start local DB on 3307 if not already running
if ! lsof -nP -iTCP:3307 -sTCP:LISTEN >/dev/null 2>&1; then
  /opt/homebrew/opt/mysql/bin/mysqld_safe \
    --datadir=/opt/homebrew/var/mysql \
    --port=3307 \
    --socket=/tmp/mysql3307.sock \
    --mysqlx=0 \
    >/tmp/wms_mysql3307.log 2>&1 &
fi

# Wait until MySQL is ready
for i in $(seq 1 20); do
  if /opt/homebrew/opt/mysql/bin/mysql -h 127.0.0.1 -P 3307 -u root -proot -e "SELECT 1" >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

# Ensure schema/data exist
/opt/homebrew/opt/mysql/bin/mysql -h 127.0.0.1 -P 3307 -u root -proot -e "DROP DATABASE IF EXISTS warehouse_db;"
/opt/homebrew/opt/mysql/bin/mysql -h 127.0.0.1 -P 3307 -u root -proot < sql/schema.sql
/opt/homebrew/opt/mysql/bin/mysql -h 127.0.0.1 -P 3307 -u root -proot < sql/sample_data.sql

# Start app in GUI mode
if [ "$NO_GUI" -eq 0 ]; then
  mvn -q clean compile exec:java
else
  echo "Setup complete. DB is ready on 127.0.0.1:3307"
fi
