USE warehouse_db;

INSERT INTO products(name, category, unit_price, reorder_level) VALUES
('Laptop', 'Electronics', 75000.00, 5),
('Office Chair', 'Furniture', 4500.00, 10),
('Printer Paper A4', 'Stationery', 350.00, 30);

INSERT INTO suppliers(name, phone, email, address) VALUES
('TechSource Pvt Ltd', '9876543210', 'sales@techsource.com', 'Mumbai, India'),
('Comfort Furnishings', '9876500000', 'contact@comfortfurnish.com', 'Pune, India'),
('PaperWorld Supplies', '9876511111', 'hello@paperworld.com', 'Delhi, India');

INSERT INTO inventory(product_id, quantity_available, warehouse_location) VALUES
(1, 8, 'A1'),
(2, 22, 'B3'),
(3, 100, 'C2');

INSERT INTO stock_transactions(product_id, supplier_id, transaction_type, quantity, transaction_date) VALUES
(1, 1, 'IN', 8, NOW()),
(2, 2, 'IN', 22, NOW()),
(3, 3, 'IN', 100, NOW());

INSERT INTO users(username, password, role) VALUES
('admin', 'admin123', 'ADMIN'),
('staff', 'staff123', 'STAFF');
