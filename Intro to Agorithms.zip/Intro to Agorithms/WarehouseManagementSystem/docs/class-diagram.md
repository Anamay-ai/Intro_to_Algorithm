# Class Diagram (Mermaid)

```mermaid
classDiagram
    class Item {
      <<abstract>>
      -int id
      -String name
      +getId()
      +setId(int)
      +getName()
      +setName(String)
      +getDisplayInfo()*
    }

    class Product {
      -String category
      -double unitPrice
      -int reorderLevel
      +setUnitPrice(double)
      +setUnitPrice(String)
      +getDisplayInfo()
    }

    class Person {
      -int id
      -String name
      -String phone
      -String email
      +getContactSummary()
    }

    class Supplier {
      -String address
      +getContactSummary()
    }

    class Inventory {
      -int inventoryId
      -int productId
      -int quantityAvailable
      -String warehouseLocation
    }

    class Transaction {
      -int transactionId
      -int productId
      -Integer supplierId
      -TransactionType transactionType
      -int quantity
      -LocalDateTime transactionDate
    }

    class ProductDAO {
      <<interface>>
    }
    class SupplierDAO {
      <<interface>>
    }
    class InventoryDAO {
      <<interface>>
    }
    class TransactionDAO {
      <<interface>>
    }

    class UserDAO {
      <<interface>>
    }

    class User {
      -int id
      -String username
      -String password
      -Role role
    }

    class Role {
      <<enum>>
      ADMIN
      STAFF
    }

    class Service
    class Menu
    class AuthService
    class LoginFrame
    class DashboardFrame
    class ApiServer
    class Main

    Item <|-- Product
    Person <|-- Supplier

    ProductDAO <|.. ProductDAOImpl
    SupplierDAO <|.. SupplierDAOImpl
    InventoryDAO <|.. InventoryDAOImpl
    TransactionDAO <|.. TransactionDAOImpl

    Service --> ProductDAO
    Service --> SupplierDAO
    Service --> InventoryDAO
    Service --> TransactionDAO
    AuthService --> UserDAO
    LoginFrame --> AuthService
    DashboardFrame --> Service
    ApiServer --> Service
    User --> Role

    Menu --> Service
    Main --> Menu
    Main --> LoginFrame
    Main --> ApiServer
```
