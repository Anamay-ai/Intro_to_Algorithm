# Warehouse Management System Project Report

## 1. Title Page
- Project Title: Warehouse Management System using Java and JDBC
- Student Name:
- Roll Number:
- Course:
- Faculty:
- Submission Date: 15 April 2026

## 2. Problem Statement
The project addresses inventory and supplier management challenges in a warehouse by providing a Java-based system to manage products, suppliers, stock levels, and stock transactions with persistent storage in a relational database.

## 3. Objectives
- Implement a modular warehouse system using layered architecture.
- Demonstrate OOP concepts: abstraction, inheritance, encapsulation, and polymorphism.
- Perform complete CRUD operations through JDBC.
- Validate data and handle runtime exceptions.

## 4. System Design
### 4.1 Architecture
- Presentation Layer: Console interface
- Business Logic Layer: Service
- Data Access Layer: DAO interfaces and JDBC implementations
- Database Layer: MySQL tables and relationships

### 4.2 Modules
- Product Management
- Supplier Management
- Inventory Management
- Stock In and Stock Out Transactions
- Search and Low Stock Alerts

## 5. Class Diagram
Attach or paste the diagram from docs/class-diagram.md.

## 6. Database Schema
Include:
- Table list
- Primary and foreign keys
- Relationships
- Schema script from sql/schema.sql

## 7. OOP Concepts Used
- Class and Object creation: Product, Supplier, Inventory, Transaction
- Constructor usage: parameterized and default constructors in models
- Inheritance: Product extends Item, Supplier extends Person
- Method overriding: getDisplayInfo and getContactSummary
- Method overloading: setUnitPrice in Product and addStock in Service
- Abstraction: abstract Item class
- Encapsulation: private fields with getters/setters
- Collections: ArrayList and HashMap in Service and DAOs

## 8. Screenshots
Add screenshots for:
- Main menu
- Add product
- Update product
- Delete product
- Search product
- Add supplier
- Add stock and remove stock
- Inventory view
- Low stock report
- Transactions view

## 9. Testing and Validation
- Positive and negative input tests
- Database connectivity tests
- CRUD operation verification

## 10. Conclusion
Summarize outcomes, strengths, and potential enhancements such as GUI, role-based access control, or REST API integration.
